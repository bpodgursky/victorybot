package state;

public abstract class Supportable extends Order{
}
